import React, { useState, useMemo, lazy, Suspense, useEffect, useCallback } from 'react';
import { Post, User, Comment, Reel, Story, Notification, Message, Bucket } from './types';
import { useAuth } from './contexts/AuthContext';
import * as api from './contexts/services/appwriteService';
import { client, DATABASE_ID, POSTS_COLLECTION_ID, COMMENTS_COLLECTION_ID, REELS_COLLECTION_ID } from './contexts/services/appwriteService';


// Statically import components that are part of the main, initial layout
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import RightSidebar from './components/RightSidebar';
import PostCard from './components/PostCard';
import CreatePost from './components/CreatePost';
import BottomNavBar from './components/BottomNavBar';
import StoriesTray from './components/StoriesTray';

// Lazy-load components that are not immediately visible (pages, modals)
const ProfilePage = lazy(() => import('./components/ProfilePage'));
const EditProfileModal = lazy(() => import('./components/EditProfileModal'));
const SettingsModal = lazy(() => import('./components/SettingsModal'));
const EditPostModal = lazy(() => import('./components/EditPostModal'));
const SearchResults = lazy(() => import('./components/SearchResults'));
const StoryViewer = lazy(() => import('./components/StoryViewer'));
const StoryCreatorModal = lazy(() => import('./components/StoryCreatorModal'));
const ShortsPage = lazy(() => import('./components/ShortsPage'));
const CreateReelModal = lazy(() => import('./components/CreateReelModal'));
const ChatPage = lazy(() => import('./components/ChatPage'));
const AddToBucketModal = lazy(() => import('./components/AddToBucketModal'));


const LoadingSpinner: React.FC = () => (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div>
    </div>
);

const ContentLoader: React.FC = () => (
    <div className="flex items-center justify-center p-8 min-h-[300px]">
        <div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div>
    </div>
);

const formatRelativeTime = (date: Date): string => {
  const now = new Date();
  const seconds = Math.round((now.getTime() - date.getTime()) / 1000);

  if (seconds < 5) return 'الآن';

  const rtf = new Intl.RelativeTimeFormat('ar', { numeric: 'auto' });

  if (seconds < 60) return rtf.format(-seconds, 'second');
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return rtf.format(-minutes, 'minute');
  const hours = Math.round(minutes / 60);
  if (hours < 24) return rtf.format(-hours, 'hour');
  const days = Math.round(hours / 24);
  if (days < 7) return rtf.format(-days, 'day');
  const weeks = Math.round(days / 7);
  if (weeks < 5) return rtf.format(-weeks, 'week');
  const months = Math.round(days / 30);
  if (months < 12) return rtf.format(-months, 'month');
  const years = Math.round(days / 365);
  return rtf.format(-years, 'year');
};

export const App: React.FC = () => {
    const { currentUser, loading, signOut, updateProfile } = useAuth();
    
    // --- STATE MANAGEMENT ---
    const [users, setUsers] = useState<Record<string, User>>({});
    const [posts, setPosts] = useState<Post[]>([]);
    const [comments, setComments] = useState<Record<string, Comment[]>>({});
    const [reels, setReels] = useState<Reel[]>([]);
    const [stories, setStories] = useState<Record<string, Story[]>>({});
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [messages, setMessages] = useState<Message[]>([]);
    const [buckets, setBuckets] = useState<Bucket[]>([]);
    const [bucketPosts, setBucketPosts] = useState<Record<string, string[]>>({});
    const [following, setFollowing] = useState<string[]>([]);
    
    // --- UI STATE ---
    const [currentPage, setCurrentPage] = useState<'home' | 'profile' | 'chat' | 'shorts'>('home');
    const [viewedProfile, setViewedProfile] = useState<User | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [editingPost, setEditingPost] = useState<Post | null>(null);
    const [isEditPostModalOpen, setIsEditPostModalOpen] = useState(false);
    const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
    const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
    const [storyViewerUserUid, setStoryViewerUserUid] = useState<string | null>(null);
    const [isStoryCreatorOpen, setIsStoryCreatorOpen] = useState(false);
    const [isCreateReelModalOpen, setIsCreateReelModalOpen] = useState(false);
    const [chatTargetUser, setChatTargetUser] = useState<User | null>(null);
    const [savingPost, setSavingPost] = useState<Post | null>(null);
    const [isAddToBucketModalOpen, setIsAddToBucketModalOpen] = useState(false);
    const [appLoading, setAppLoading] = useState(true);

    // --- DATA FETCHING ---
    const fetchData = useCallback(async () => {
        setAppLoading(true);
        try {
            const promises: any[] = [
                api.getUsers(),
                api.getPosts(),
                api.getAllComments(),
                api.getReels(),
            ];
            
            if (currentUser) {
                promises.push(api.getNotificationsForUser(currentUser.uid));
            }

            const [fetchedUsers, fetchedPosts, fetchedComments, fetchedReels, fetchedNotifications] = await Promise.all(promises);
            
            const usersMap = fetchedUsers.reduce((acc, user) => {
                acc[user.uid] = user;
                return acc;
            }, {} as Record<string, User>);
            setUsers(usersMap);
            setPosts(fetchedPosts);

            const commentsMap = fetchedComments.reduce((acc, comment) => {
                const postId = comment.postId;
                if (!acc[postId]) acc[postId] = [];
                acc[postId].push({ ...comment, author: usersMap[comment.authorId] });
                return acc;
            }, {} as Record<string, Comment[]>);
            setComments(commentsMap);
            
            const reelsWithAuthors = fetchedReels.map(reel => ({
                ...reel,
                author: usersMap[reel.authorId],
                comments: (commentsMap[reel.$id] || [])
            })).filter(reel => reel.author);
            setReels(reelsWithAuthors);

            if (fetchedNotifications) {
                const notificationsWithActors = fetchedNotifications.map(n => ({
                    ...n,
                    actor: usersMap[n.actorId],
                    timestamp: formatRelativeTime(new Date(n.$createdAt))
                })).filter(n => n.actor);
                setNotifications(notificationsWithActors);
            }

        } catch (error) {
            console.error("Failed to fetch data:", error);
        } finally {
            setAppLoading(false);
        }
    }, [currentUser]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);
    
    
    // --- REALTIME SUBSCRIPTIONS ---
    useEffect(() => {
        if (!currentUser) return;

        const postUnsubscribe = client.subscribe(`databases.${DATABASE_ID}.collections.${POSTS_COLLECTION_ID}.documents`, response => {
            const event = response.events.find(e => e.includes('.documents.') && (e.endsWith('.create') || e.endsWith('.update') || e.endsWith('.delete')));
            if (event) {
                api.getPosts().then(setPosts); // Simple refetch on any change
            }
        });

        const commentUnsubscribe = client.subscribe(`databases.${DATABASE_ID}.collections.${COMMENTS_COLLECTION_ID}.documents`, async response => {
            if (response.events.some(e => e.endsWith('.create'))) {
                const newComment = response.payload as Comment;
                
                // Optimistically update comments state
                const author = users[newComment.authorId] || await api.getUserProfile(newComment.authorId);
                if (author && !users[author.uid]) setUsers(prev => ({...prev, [author.uid]: author}));
                
                const newCommentWithAuthor = { ...newComment, author };
                setComments(prev => ({ ...prev, [newComment.postId]: [...(prev[newComment.postId] || []), newCommentWithAuthor] }));

                const post = posts.find(p => p.$id === newComment.postId);
                if (post && post.authorId === currentUser.uid && newComment.authorId !== currentUser.uid) {
                    await api.createNotification(currentUser.uid, newComment.authorId, 'comment');
                    new Notification(`تعليق جديد من ${author.name}`, {
                        body: newComment.text,
                        icon: author.avatarUrl,
                        dir: 'rtl'
                    });
                }
            }
        });
        
        const reelUnsubscribe = client.subscribe(`databases.${DATABASE_ID}.collections.${REELS_COLLECTION_ID}.documents`, async response => {
             if (response.events.some(e => e.endsWith('.create'))) {
                fetchData(); // Refetch all data for simplicity
             }
        });
        
        const notificationUnsubscribe = client.subscribe(`databases.${DATABASE_ID}.collections.${api.NOTIFICATIONS_COLLECTION_ID}.documents`, async response => {
            if (response.events.some(e => e.endsWith('.create'))) {
                const newNotification = response.payload as Notification;
                if (newNotification.recipientId === currentUser.uid) {
                    const actor = users[newNotification.actorId] || await api.getUserProfile(newNotification.actorId);
                    if (actor) {
                        if(!users[actor.uid]) setUsers(prev => ({...prev, [actor.uid]: actor}));
                        const notificationWithActor = { 
                            ...newNotification, 
                            actor, 
                            timestamp: formatRelativeTime(new Date(newNotification.$createdAt)) 
                        };
                        setNotifications(prev => [notificationWithActor, ...prev]);
                    }
                }
            }
        });

        return () => {
            postUnsubscribe();
            commentUnsubscribe();
            reelUnsubscribe();
            notificationUnsubscribe();
        };
    }, [currentUser, users, posts, fetchData]);

    // --- COMPUTED DATA ---
    const postsWithAuthors = useMemo(() => {
        return posts
            .map(post => ({
                ...post,
                author: users[post.authorId],
                isLiked: currentUser ? post.likes.includes(currentUser.uid) : false,
            }))
            .filter(post => post.author);
    }, [posts, users, currentUser]);
        
    const allUsers = useMemo(() => Object.values(users), [users]);
    const unreadNotificationCount = useMemo(() => notifications.filter(n => !n.read).length, [notifications]);
    const storyGroups = useMemo(() => {
        return Object.entries(stories).map(([userUid, userStories]) => ({
            user: users[userUid],
            hasUnviewed: Array.isArray(userStories) && userStories.some(s => !s.viewed)
        })).filter(group => group.user);
    }, [stories, users]);
    const followingUsers = useMemo(() => following.map(uid => users[uid]).filter(Boolean), [following, users]);

    // --- EVENT HANDLERS (DATABASE MANIPULATION) ---

    const handleAddPost = async (text: string, media?: { url: string; type: 'image' | 'video', fileId: string }) => {
        if (!currentUser) return;
        await api.createPost(currentUser.uid, text, media);
    };

    const handleEditPost = (post: Post) => {
        setEditingPost(post);
        setIsEditPostModalOpen(true);
    };

    const handleSavePost = async (postId: string, newText: string) => {
        const updatedPost = await api.updatePost(postId, { text: newText });
        setPosts(posts.map(p => p.$id === postId ? { ...p, ...updatedPost } : p));
        setIsEditPostModalOpen(false);
        setEditingPost(null);
    };
    
    const handleDeletePost = async (postId: string) => {
        await api.deletePost(postId);
        setPosts(posts.filter(p => p.$id !== postId));
    };

    const handleLikePost = async (postId: string) => {
        if (!currentUser) return;
        const post = posts.find(p => p.$id === postId);
        if (!post) return;

        const newLikes = post.likes.includes(currentUser.uid)
            ? post.likes.filter(uid => uid !== currentUser.uid)
            : [...post.likes, currentUser.uid];
        
        const originalPosts = posts;
        setPosts(posts.map(p => p.$id === postId ? { ...p, likes: newLikes, isLiked: !p.isLiked } : p));
        
        try {
            await api.updatePost(postId, { likes: newLikes });
        } catch (error) {
            console.error("Failed to like post:", error);
            setPosts(originalPosts);
        }
    };


    const handleAddComment = async (postId: string, text: string) => {
        if (!currentUser) return;
        await api.createComment(postId, currentUser.uid, text);
    };
    
    const handleSharePost = async (postId: string) => {
        const post = posts.find(p => p.$id === postId);
        if(!post) return;
        const updatedPost = await api.updatePost(postId, { shares: (post.shares || 0) + 1 });
        setPosts(posts.map(p => p.$id === postId ? { ...p, ...updatedPost } : p));
    };

    const handleSavePostClick = (post: Post) => {
        setSavingPost(post);
        // setIsAddToBucketModalOpen(true);
    };
    
    const handleSaveChange = (postId: string, isSaved: boolean) => {
       // setPosts(posts.map(p => p.$id === postId ? { ...p, isSaved } : p));
    };

    const handleFollowToggle = (userUid: string) => {
        if (!currentUser) return;
        setFollowing(prev => prev.includes(userUid) ? prev.filter(uid => uid !== userUid) : [...prev, userUid]);
    };

    const handleProfileUpdate = async (updatedUser: User) => {
        if (!currentUser) return;
        const updatedProfile = await api.updateUserProfile(currentUser.uid, updatedUser);
        const newUser = { ...currentUser, ...updatedProfile };
        setUsers(prev => ({...prev, [newUser.uid]: newUser}));
        await updateProfile(newUser);
        setIsEditProfileModalOpen(false);
    };

    const handleAddStory = (storyData: {type: 'image' | 'text', content: string, caption?: string, backgroundColor?: string}) => {
        // Implement Appwrite logic
    };

    const handleAddReel = async (videoUrl: string, caption: string) => {
      if (!currentUser) return;
      const newReel = await api.createReel(currentUser.uid, videoUrl, caption);
      // Optimistically update the UI to show the new reel immediately.
      setReels(prev => [{ 
          ...newReel, 
          author: currentUser, 
          comments: [], 
          likes: [], 
          isLiked: false 
      }, ...prev]);
    };

    const handleSendMessage = (recipient: User, text: string) => {
        // Implement Appwrite logic
    };
    
    // --- NAVIGATION ---
    const handleViewProfile = (user: User) => {
        setViewedProfile(user);
        setCurrentPage('profile');
        window.scrollTo(0, 0);
    };
    
    const goToHome = () => {
        setCurrentPage('home');
        setViewedProfile(null);
        setSearchQuery('');
    };
    
    // --- RENDER LOGIC ---

    if (loading || appLoading) return <LoadingSpinner />;

    const searchedUsers = searchQuery ? allUsers.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase())) : [];
    const searchedPosts = searchQuery ? postsWithAuthors.filter(p => p.text.toLowerCase().includes(searchQuery.toLowerCase())) : [];
    
    const renderContent = () => {
        if (searchQuery) {
            return <SearchResults users={searchedUsers} posts={searchedPosts} currentUser={currentUser} comments={comments} onViewProfile={handleViewProfile} onLike={handleLikePost} onAddComment={handleAddComment} onShare={handleSharePost} onSave={handleSavePostClick} onEdit={handleEditPost} onDelete={handleDeletePost} query={searchQuery} following={following} onFollowToggle={handleFollowToggle} />;
        }
        
        switch (currentPage) {
            case 'profile':
                const profileUser = viewedProfile;
                if (!profileUser) {
                    goToHome();
                    return null;
                }
                const userPosts = postsWithAuthors.filter(p => p.authorId === profileUser.uid);
                const userReels = reels.filter(r => r.authorId === profileUser.uid);
                return <ProfilePage user={profileUser} posts={userPosts} reels={userReels} comments={comments} onLike={handleLikePost} onSave={handleSavePostClick} onAddComment={handleAddComment} onShare={handleSharePost} onAddPost={handleAddPost} currentUser={currentUser} handleViewProfile={handleViewProfile} onEditProfile={() => setIsEditProfileModalOpen(true)} onOpenSettings={() => setIsSettingsModalOpen(true)} onGoToChat={(user) => { setChatTargetUser(user); setCurrentPage('chat');}} following={following} onFollowToggle={handleFollowToggle} viewers={[]} onEditPost={handleEditPost} onDeletePost={handleDeletePost} buckets={buckets.filter(b => b.user_id === profileUser.uid)} />;
            case 'shorts':
                return <ShortsPage reels={reels} currentUser={currentUser} onLike={() => {}} onAddComment={() => {}} onShare={() => {}} onAddReel={() => setIsCreateReelModalOpen(true)} onViewProfile={handleViewProfile} />;
            case 'chat':
                 if (!currentUser) {
                    goToHome();
                    return null;
                }
                return <ChatPage currentUser={currentUser} allUsers={users} messages={messages} onSendMessage={handleSendMessage} followingUsers={followingUsers} initialTargetUser={chatTargetUser} onClearTargetUser={() => setChatTargetUser(null)} onViewProfile={handleViewProfile} />;
            case 'home':
            default:
                return (
                    <div>
                        {currentUser && <StoriesTray storyGroups={storyGroups} currentUser={currentUser} onViewStories={setStoryViewerUserUid} onAddStory={() => setIsStoryCreatorOpen(true)} />}
                        {currentUser && <CreatePost currentUser={currentUser} onAddPost={handleAddPost} />}
                        {postsWithAuthors.map(post => (
                            <PostCard key={post.$id} post={post} currentUser={currentUser} comments={comments[post.$id] || []} onLike={handleLikePost} onAddComment={handleAddComment} onShare={handleSharePost} onSave={handleSavePostClick} onViewProfile={handleViewProfile} onEdit={handleEditPost} onDelete={handleDeletePost} />
                        ))}
                    </div>
                );
        }
    };

    return (
        <div className="bg-slate-100 min-h-screen">
            <Header currentUser={currentUser} searchQuery={searchQuery} onSearchChange={setSearchQuery} notifications={notifications} unreadNotificationCount={unreadNotificationCount} onViewProfile={handleViewProfile} onGoToHome={goToHome} onGoToShorts={() => setCurrentPage('shorts')} currentPage={currentPage} onNotificationNavigate={() => {}} />
            <main className="max-w-7xl mx-auto pt-20 px-4 pb-24 lg:pb-4">
                <div className="grid grid-cols-12 gap-6">
                    <div className="hidden lg:block lg:col-span-3">
                        <Sidebar currentUser={currentUser} allUsers={allUsers} following={following} onViewProfile={handleViewProfile} onFollowToggle={handleFollowToggle} />
                    </div>
                    <div className="col-span-12 lg:col-span-6">
                         <Suspense fallback={<ContentLoader />}>{renderContent()}</Suspense>
                    </div>
                    <div className="hidden lg:block lg:col-span-3">
                        <RightSidebar currentUser={currentUser} allUsers={users} messages={messages} onSendMessage={handleSendMessage} followingUsers={followingUsers} onViewProfile={handleViewProfile} initialTargetUser={chatTargetUser} onClearTargetUser={() => setChatTargetUser(null)} />
                    </div>
                </div>
            </main>
            <BottomNavBar currentPage={currentPage} searchQuery={searchQuery} viewedProfileUid={viewedProfile?.uid || null} currentUser={currentUser} onHomeClick={goToHome} onShortsClick={() => setCurrentPage('shorts')} onProfileClick={() => currentUser && handleViewProfile(currentUser)} onChatClick={() => setCurrentPage('chat')} />
            
            {/* --- Modals --- */}
            <Suspense fallback={null}>
                {isEditPostModalOpen && <EditPostModal isOpen={isEditPostModalOpen} onClose={() => setIsEditPostModalOpen(false)} post={editingPost} onSave={handleSavePost} />}
                {isEditProfileModalOpen && currentUser && <EditProfileModal isOpen={isEditProfileModalOpen} onClose={() => setIsEditProfileModalOpen(false)} user={currentUser} onSave={handleProfileUpdate} />}
                {isSettingsModalOpen && <SettingsModal isOpen={isSettingsModalOpen} onClose={() => setIsSettingsModalOpen(false)} onLogout={signOut} />}
                {storyViewerUserUid && <StoryViewer user={users[storyViewerUserUid]} stories={stories[storyViewerUserUid] || []} onClose={() => setStoryViewerUserUid(null)} onNextUser={() => {}} onPrevUser={() => {}} onMarkAsViewed={(storyId) => {}} />}
                {isStoryCreatorOpen && <StoryCreatorModal isOpen={isStoryCreatorOpen} onClose={() => setIsStoryCreatorOpen(false)} onAddStory={handleAddStory} />}
                {isCreateReelModalOpen && <CreateReelModal isOpen={isCreateReelModalOpen} onClose={() => setIsCreateReelModalOpen(false)} onAddReel={handleAddReel} />}
                {isAddToBucketModalOpen && savingPost && <AddToBucketModal isOpen={isAddToBucketModalOpen} onClose={() => setIsAddToBucketModalOpen(false)} post={savingPost} onSaveChange={handleSaveChange} buckets={buckets} bucketPosts={bucketPosts} setBucketPosts={()=>{}} setBuckets={setBuckets} />}
            </Suspense>
        </div>
    );
};