// This file is deprecated. All data is now fetched from the Appwrite backend.
export {};
