
import { Models } from 'appwrite';

// Fix: Added optional fields to User type to support profile information.
export interface User extends Models.Document {
  uid: string;
  name: string;
  avatarUrl: string;
  email: string;
  bio?: string;
  isOnline?: boolean;
  fcmToken?: string;
  gender?: {
      value: string;
      isPublic: boolean;
  };
  country?: {
      value: string;
      isPublic: boolean;
  };
}

export interface Post extends Models.Document {
  authorId: string;
  text: string;
  imageUrl?: string;
  videoUrl?: string;
  likes: string[]; // Array of user uids
  shares: number;
  timestamp: string;
  
  // Client-side populated
  author?: User;
  comments?: number;
  isLiked?: boolean;
  isSaved?: boolean;
}

// Fix: Added missing Comment type definition.
export interface Comment extends Models.Document {
  authorId: string;
  postId: string;
  text: string;

  // Client-side populated
  author?: User;
}

// Fix: Added missing Reel type definition.
// FIX: Changed Reel from an interface to a type alias to ensure properties from Models.Document (like $id) are correctly inherited.
export type Reel = Models.Document & {
  authorId: string;
  videoUrl: string;
  caption: string;
  music?: string;
  likes: string[];
  shares: number;

  // Client-side populated
  author?: User;
  isLiked?: boolean;
  // FIX: Made comments optional as it's a client-populated field not present in initial API response.
  comments?: Comment[];
};

// Fix: Added missing NotificationType type definition.
export type NotificationType = 'like' | 'comment' | 'follow' | 'message';

// Fix: Added missing Notification type definition.
export interface Notification extends Models.Document {
  // FIX: Added missing $createdAt property to align with Appwrite's document model.
  $createdAt: string;
  actorId: string;
  recipientId: string;
  type: NotificationType;
  read: boolean;
  
  // Client-side populated
  actor?: User;
  timestamp?: string; // Appwrite provides $createdAt
}

// Fix: Added missing Message type definition.
export interface Message extends Models.Document {
  senderKey: string;
  receiverKey: string;
  text: string;
  timestamp: string; // Appwrite provides $createdAt
}

// Fix: Added missing Story type definition.
export interface Story extends Models.Document {
  authorId: string;
  type: 'image' | 'text';
  content: string; // URL for image, text content for text
  caption?: string;
  backgroundColor?: string;
  
  // Client-side populated
  viewed?: boolean;
  author?: User;
}

// Fix: Changed Bucket from interface to a type alias to ensure properties from Models.Document are correctly inherited.
export type Bucket = Models.Document & {
  user_id: string;
  name: string;
};

export interface BucketPost extends Models.Document {
    bucket_id: string;
    post_id: string;
}