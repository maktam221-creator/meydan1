import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { XIcon } from './Icons';
import { uploadFile } from '../contexts/services/appwriteService';

interface CreateReelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddReel: (videoUrl: string, caption: string) => void;
}

const CreateReelModal: React.FC<CreateReelModalProps> = ({ isOpen, onClose, onAddReel }) => {
  const [prompt, setPrompt] = useState('');
  const [caption, setCaption] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [apiKeySelected, setApiKeySelected] = useState<boolean | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkApiKey();
    }
  }, [isOpen]);

  const checkApiKey = async () => {
    if (await window.aistudio.hasSelectedApiKey()) {
      setApiKeySelected(true);
    } else {
      setApiKeySelected(false);
    }
  };

  const handleSelectKey = async () => {
    await window.aistudio.openSelectKey();
    // Assume selection was successful and update UI immediately
    setApiKeySelected(true);
  };
  
  const resetState = () => {
    setPrompt('');
    setCaption('');
    setIsGenerating(false);
    setGenerationStatus('');
    setError(null);
    setApiKeySelected(null); // Reset for next time modal opens
  };
  
  const handleClose = () => {
      if (isGenerating) return;
      resetState();
      onClose();
  }

  const handleSubmit = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setError(null);
    setGenerationStatus('Initializing generation...');
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        setGenerationStatus('Starting video operation...');
        let operation = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: prompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '9:16'
            }
        });
        
        setGenerationStatus('Generating video... This can take a few minutes.');
        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 10000));
            operation = await ai.operations.getVideosOperation({operation: operation});
        }
        
        setGenerationStatus('Finalizing video...');
        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

        if (!downloadLink) {
            throw new Error("Video generation succeeded but no download link was found.");
        }

        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        if (!videoResponse.ok) {
            throw new Error(`Failed to download generated video. Status: ${videoResponse.status}`);
        }
        
        const videoBlob = await videoResponse.blob();
        const videoFile = new File([videoBlob], "generated-reel.mp4", { type: "video/mp4" });

        setGenerationStatus('Uploading to server...');
        const { url } = await uploadFile(videoFile);
        
        onAddReel(url, caption || prompt);
        handleClose();

    } catch(err: any) {
        console.error("Failed to generate or add reel:", err);
        if (err.message?.includes("Requested entity was not found.")) {
             setError("Your API Key is invalid. Please select a valid key.");
             setApiKeySelected(false);
        } else {
            setError("Failed to generate video. Please try again.");
        }
        setIsGenerating(false);
    }
  };

  const renderContent = () => {
    if (apiKeySelected === null) {
      return (
        <div className="text-center py-12">
          <div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-lg text-slate-600">Checking API key...</p>
        </div>
      );
    }

    if (apiKeySelected === false) {
      return (
        <div className="text-center py-8">
            <h3 className="text-lg font-semibold text-slate-800">API Key Required</h3>
            <p className="text-slate-600 mt-2 mb-4">Video generation with Veo is a billable service. Please select an API key associated with a project that has billing enabled.</p>
            <p className="text-sm text-slate-500 mb-6">
                For more information, see the <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">billing documentation</a>.
            </p>
            {error && (
              <div className="mb-4 p-3 text-sm text-center text-red-700 bg-red-100 rounded-md">
                {error}
              </div>
            )}
            <button
                onClick={handleSelectKey}
                className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors"
            >
                Select API Key
            </button>
        </div>
      );
    }

    if (isGenerating) {
        return (
            <div className="text-center py-12">
                <div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin mx-auto"></div>
                <p className="mt-4 text-lg text-slate-600">{generationStatus}</p>
                <p className="text-sm text-slate-500">Please keep this window open.</p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {error && (
              <div className="p-3 text-sm text-center text-red-700 bg-red-100 rounded-md">
                {error}
              </div>
            )}
            <div>
              <label htmlFor="prompt" className="block text-sm font-medium text-slate-700 mb-1">
                Video Prompt
              </label>
              <textarea
                id="prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={4}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition resize-none"
                placeholder="e.g., A neon hologram of a cat driving at top speed"
              />
            </div>
            <div>
              <label htmlFor="caption" className="block text-sm font-medium text-slate-700 mb-1">
                Caption (Optional)
              </label>
              <input
                id="caption"
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                placeholder="Describe your new video..."
              />
            </div>
            <div className="flex justify-end pt-2">
              <button
                onClick={handleSubmit}
                disabled={!prompt.trim() || isGenerating}
                className="px-8 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors"
              >
                Generate
              </button>
            </div>
        </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-slate-800 bg-opacity-90 z-50 flex justify-center items-center" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md m-4 p-6 relative animate-fade-in-up">
        <div className="flex justify-between items-center border-b pb-3 mb-5">
          <h2 className="text-xl font-bold text-slate-800">Generate a New Reel</h2>
          <button onClick={handleClose} className="p-2 rounded-full hover:bg-slate-100 transition-colors" aria-label="إغلاق">
            <XIcon className="w-6 h-6 text-slate-500" />
          </button>
        </div>
        {renderContent()}
      </div>
    </div>
  );
};

export default CreateReelModal;