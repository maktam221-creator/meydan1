import React, { useState, useMemo } from 'react';
import { Post, Bucket } from '../types';
import { XIcon, PlusIcon } from './Icons';
import { useAuth } from '../contexts/AuthContext';

interface AddToBucketModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post;
  onSaveChange: (postId: string, isSaved: boolean) => void;
  buckets: Bucket[];
  bucketPosts: Record<string, string[]>;
  setBucketPosts: React.Dispatch<React.SetStateAction<Record<string, string[]>>>;
  setBuckets: React.Dispatch<React.SetStateAction<Bucket[]>>;
}

const AddToBucketModal: React.FC<AddToBucketModalProps> = ({ 
  isOpen, 
  onClose, 
  post, 
  onSaveChange, 
  buckets, 
  bucketPosts,
  setBucketPosts,
  setBuckets
}) => {
  const { currentUser } = useAuth();
  const [newBucketName, setNewBucketName] = useState('');
  const [isLoading] = useState(false); // No async operations needed anymore

  const selectedBucketIds = useMemo(() => {
    if (!post) return new Set<string>();
    const ids = Object.entries(bucketPosts)
      .filter(([, postIds]) => Array.isArray(postIds) && postIds.includes(post.$id))
      .map(([bucketId]) => bucketId);
    return new Set(ids);
  }, [bucketPosts, post]);
  
  if (!isOpen || !post || !currentUser) {
    return null;
  }

  const handleToggleBucket = (bucketId: string) => {
    const isCurrentlyInBucket = selectedBucketIds.has(bucketId);

    setBucketPosts(prev => {
      const newBucketPosts = {...prev};
      if(isCurrentlyInBucket) {
        newBucketPosts[bucketId] = newBucketPosts[bucketId]?.filter(id => id !== post.$id) || [];
      } else {
        newBucketPosts[bucketId] = [...(newBucketPosts[bucketId] || []), post.$id];
      }
      return newBucketPosts;
    });

    const newSelectedIds = new Set(selectedBucketIds);
    if (isCurrentlyInBucket) newSelectedIds.delete(bucketId);
    else newSelectedIds.add(bucketId);

    onSaveChange(post.$id, newSelectedIds.size > 0);
  };

  const handleCreateBucket = (e: React.FormEvent) => {
    e.preventDefault();
    if (newBucketName.trim() && currentUser) {
      // FIX: Cast the locally created object to Bucket to resolve TypeScript errors.
      // The type definition for Bucket seems to not correctly inherit $id for the compiler,
      // so we assert the type to ensure compatibility. This fixes errors on lines 67 and 79.
      const newBucket = {
        $id: Date.now().toString(),
        user_id: currentUser.uid,
        name: newBucketName.trim(),
        $collectionId: '',
        $databaseId: '',
        $createdAt: '',
        $updatedAt: '',
        $permissions: []
      } as Bucket;
      setBuckets(prev => [newBucket, ...prev]);
      setNewBucketName('');
      // Also add the post to this new bucket immediately
      handleToggleBucket(newBucket.$id);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-sm m-4 p-6 relative animate-fade-in-up">
        <div className="flex justify-between items-center border-b pb-3 mb-5">
          <h2 className="text-xl font-bold text-slate-800">حفظ في قائمة</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 transition-colors" aria-label="إغلاق">
            <XIcon className="w-6 h-6 text-slate-500" />
          </button>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-48">
            <div className="w-8 h-8 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <form onSubmit={handleCreateBucket} className="flex items-center space-x-2 rtl:space-x-reverse mb-4">
              <input
                type="text"
                value={newBucketName}
                onChange={(e) => setNewBucketName(e.target.value)}
                placeholder="إنشاء قائمة جديدة..."
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              />
              <button
                type="submit"
                className="p-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:bg-indigo-300 transition-colors shrink-0"
                disabled={!newBucketName.trim()}
                aria-label="إنشاء قائمة"
              >
                <PlusIcon className="w-6 h-6" />
              </button>
            </form>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {buckets.map((bucket) => (
                <label key={bucket.$id} className="flex items-center space-x-3 rtl:space-x-reverse p-3 rounded-md hover:bg-slate-50 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedBucketIds.has(bucket.$id)}
                    onChange={() => handleToggleBucket(bucket.$id)}
                    className="h-5 w-5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                  />
                  <span className="text-slate-700 font-medium">{bucket.name}</span>
                </label>
              ))}
            </div>
          </>
        )}
        
        <div className="flex justify-end pt-4 mt-4 border-t">
            <button onClick={onClose} className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors">
                تم
            </button>
        </div>
      </div>
    </div>
  );
};

export default AddToBucketModal;
