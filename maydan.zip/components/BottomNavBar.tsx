import React from 'react';
import { HomeIcon, BellIcon, UserIcon, ChatBubbleLeftRightIcon, VideoCameraIcon } from './Icons';
import { User } from '../types';

type Page = 'home' | 'profile' | 'chat' | 'shorts';

interface BottomNavBarProps {
    currentPage: Page;
    searchQuery: string;
    viewedProfileUid: string | null;
    currentUser: User | null;
    onHomeClick: () => void;
    onShortsClick: () => void;
    onProfileClick: () => void;
    onChatClick: () => void;
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ 
    currentPage, 
    searchQuery, 
    viewedProfileUid, 
    currentUser, 
    onHomeClick, 
    onShortsClick, 
    onProfileClick,
    onChatClick
}) => {
    
    const navItems = [
        { name: 'الرئيسية', icon: HomeIcon, action: onHomeClick, active: currentPage === 'home' && !searchQuery },
        { name: 'فيديوهات', icon: VideoCameraIcon, action: onShortsClick, active: currentPage === 'shorts' },
    ];

    if (currentUser) {
        navItems.push(
            { name: 'الدردشات', icon: ChatBubbleLeftRightIcon, action: onChatClick, active: currentPage === 'chat' },
            { name: 'ملفي', icon: UserIcon, action: onProfileClick, active: currentPage === 'profile' && viewedProfileUid === currentUser.uid }
        );
    }

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-[0_-1px_3px_rgba(0,0,0,0.05)] z-40">
      <div className="max-w-7xl mx-auto flex justify-around">
        {navItems.map(item => (
          <button
            key={item.name}
            onClick={item.action}
            className="flex-1 flex flex-col items-center justify-center pt-2 pb-1 text-xs font-medium transition-colors group focus:outline-none"
            aria-label={item.name}
          >
            <div className="relative">
              <item.icon className={`w-7 h-7 mb-1 transition-colors ${item.active ? 'text-indigo-600' : 'text-slate-500 group-hover:text-indigo-500'}`} />
            </div>
            <span className={`transition-colors ${item.active ? 'text-indigo-600' : 'text-slate-600 group-hover:text-indigo-500'}`}>
                {item.name}
            </span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNavBar;