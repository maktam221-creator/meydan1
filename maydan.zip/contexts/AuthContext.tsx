import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from 'react';
import { User } from '../types';
import * as api from './services/appwriteService';
import { Models } from 'appwrite';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  signOut: () => Promise<void>;
  updateProfile: (updatedProfile: User) => Promise<void>;
  login: (credentials: api.LoginCredentials) => Promise<Models.Session>;
  signup: (credentials: api.SignupCredentials) => Promise<User | undefined>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // Authentication is disabled. The app is public.
    const currentUser: User | null = null;
    const loading = false;

    const signOut = async () => {
        // No-op
    };

    const updateProfile = async (updatedProfile: User) => {
        // No-op
    };

    const login = async (credentials: api.LoginCredentials): Promise<Models.Session> => {
        throw new Error("Login functionality is disabled.");
    };

    const signup = async (credentials: api.SignupCredentials): Promise<User | undefined> => {
        throw new Error("Signup functionality is disabled.");
    };

    const value = { currentUser, loading, signOut, updateProfile, login, signup };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};