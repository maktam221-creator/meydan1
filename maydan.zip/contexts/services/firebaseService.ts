// This service was removed as per the user's request to replace Firebase.
// A client-only push notification feature using Appwrite is not available.
// It requires a server-side implementation via Appwrite Functions.
export {};
