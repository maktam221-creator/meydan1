import { Client, Account, ID, Databases, Query, Storage, Models, Permission, Role } from 'appwrite';
import { User, Post, Comment, Notification, NotificationType, Reel } from '../../types';

const client = new Client();

client
    .setEndpoint("https://cloud.appwrite.io/v1")
    .setProject("690d02990029edb5344a");

export const account = new Account(client);
export const databases = new Databases(client);
export const storage = new Storage(client);

// Database and Collection IDs - Replace with your actual IDs from Appwrite console
export const DATABASE_ID = 'default';
export const USERS_COLLECTION_ID = 'users';
export const POSTS_COLLECTION_ID = 'posts';
export const COMMENTS_COLLECTION_ID = 'comments';
export const REELS_COLLECTION_ID = 'reels';
export const STORIES_COLLECTION_ID = 'stories';
export const BUCKETS_COLLECTION_ID = 'buckets';
export const BUCKET_POSTS_COLLECTION_ID = 'bucket_posts';
export const FOLLOWERS_COLLECTION_ID = 'followers';
export const NOTIFICATIONS_COLLECTION_ID = 'notifications';


// Storage Bucket ID
export const MEDIA_BUCKET_ID = 'media';

export { client };

// --- Authentication Functions ---

export interface LoginCredentials {
    email: string;
    password: string;
}

export interface SignupCredentials extends LoginCredentials {
    name: string;
}

export const login = async ({ email, password }: LoginCredentials): Promise<Models.Session> => {
    return account.createEmailPasswordSession(email, password);
};

export const signup = async ({ email, password, name }: SignupCredentials): Promise<Models.User<Models.Preferences>> => {
    return account.create(ID.unique(), email, password, name);
};

export const logout = async (): Promise<void> => {
    return account.deleteSession('current');
};

export const getCurrentUserAccount = async (): Promise<Models.User<Models.Preferences> | null> => {
    try {
        return await account.get();
    } catch (error) {
        return null;
    }
};

// --- User Profile Functions ---

export const createUserProfile = async (userId: string, data: Partial<User>): Promise<User> => {
    // These permissions ensure that only the user themselves can read, update, or delete their own profile document.
    const permissions = [
        Permission.read(Role.user(userId)),
        Permission.update(Role.user(userId)),
        Permission.delete(Role.user(userId)),
    ];

    return databases.createDocument(
        DATABASE_ID,
        USERS_COLLECTION_ID,
        userId,
        data,
        permissions // Added permissions for security
    );
};

export const getUserProfile = async (userId: string): Promise<User | null> => {
    try {
        return await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, userId);
    } catch (error) {
        console.error(`Failed to get user profile ${userId}:`, error);
        return null;
    }
};

export const getUsers = async (): Promise<User[]> => {
    const response = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID);
    return response.documents as User[];
};

export const updateUserProfile = async (userId: string, data: Partial<User>): Promise<User> => {
    return databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, userId, data);
};

// --- Post Functions ---
export const createPost = async (authorId: string, text: string, media?: { url: string, fileId: string, type: 'image' | 'video' }): Promise<Post> => {
    const postData = {
        authorId,
        text,
        imageUrl: media?.type === 'image' ? media.url : undefined,
        videoUrl: media?.type === 'video' ? media.url : undefined,
        likes: [],
        shares: 0,
        timestamp: new Date().toISOString(),
    };
    return databases.createDocument(
        DATABASE_ID,
        POSTS_COLLECTION_ID,
        ID.unique(),
        postData
    );
};

export const getPosts = async (): Promise<Post[]> => {
    const response = await databases.listDocuments(
        DATABASE_ID, 
        POSTS_COLLECTION_ID,
        [Query.orderDesc('timestamp')]
    );
    return response.documents as Post[];
};

export const updatePost = async (postId: string, data: Partial<Post>): Promise<Post> => {
    return databases.updateDocument(DATABASE_ID, POSTS_COLLECTION_ID, postId, data);
};

export const deletePost = async (postId: string): Promise<void> => {
    return databases.deleteDocument(DATABASE_ID, POSTS_COLLECTION_ID, postId);
};


// --- Comment Functions ---
export const createComment = async (postId: string, authorId: string, text: string): Promise<Comment> => {
    const commentData = {
        postId,
        authorId,
        text,
    };
    return databases.createDocument(
        DATABASE_ID,
        COMMENTS_COLLECTION_ID,
        ID.unique(),
        commentData
    );
};

export const getCommentsForPost = async (postId: string): Promise<Comment[]> => {
    const response = await databases.listDocuments(
        DATABASE_ID,
        COMMENTS_COLLECTION_ID,
        [Query.equal('postId', postId), Query.orderDesc('$createdAt')]
    );
    return response.documents as Comment[];
};

export const getAllComments = async (): Promise<Comment[]> => {
    const response = await databases.listDocuments(
        DATABASE_ID,
        COMMENTS_COLLECTION_ID
    );
    return response.documents as Comment[];
};

// --- Notification Functions ---
export const createNotification = async (recipientId: string, actorId: string, type: NotificationType): Promise<Notification> => {
    const notificationData = {
        recipientId,
        actorId,
        type,
        read: false,
    };
    return databases.createDocument(
        DATABASE_ID,
        NOTIFICATIONS_COLLECTION_ID,
        ID.unique(),
        notificationData
    );
};

export const getNotificationsForUser = async (userId: string): Promise<Notification[]> => {
    const response = await databases.listDocuments(
        DATABASE_ID,
        NOTIFICATIONS_COLLECTION_ID,
        [Query.equal('recipientId', userId), Query.orderDesc('$createdAt')]
    );
    return response.documents as Notification[];
};


// --- Reel Functions ---
export const createReel = async (authorId: string, videoUrl: string, caption: string): Promise<Reel> => {
    const reelData = {
        authorId,
        videoUrl,
        caption,
        likes: [],
        shares: 0,
    };
    return databases.createDocument(
        DATABASE_ID,
        REELS_COLLECTION_ID,
        ID.unique(),
        reelData
    );
};

export const getReels = async (): Promise<Reel[]> => {
    const response = await databases.listDocuments(
        DATABASE_ID, 
        REELS_COLLECTION_ID,
        [Query.orderDesc('$createdAt')]
    );
    return response.documents as Reel[];
};

// --- Storage Functions ---
export const uploadFile = async (file: File): Promise<{ fileId: string; url: string }> => {
    const response = await storage.createFile(MEDIA_BUCKET_ID, ID.unique(), file);
    const fileId = response.$id;
    const url = storage.getFilePreview(MEDIA_BUCKET_ID, fileId).href;
    return { fileId, url };
};
